INSTRUCCIONES IMPORTANTES:

1) Añadir archivo google-services.json:
   - Crea un proyecto en Firebase console.
   - Añade una app Android con applicationId 'com.example.loginregistro'.
   - Descarga google-services.json y colócalo en app/ (sustituir si existe).

2) Habilitar Authentication -> Email/Password en Firebase Console.

3) Abrir el proyecto en Android Studio y sincronizar Gradle.
   - Build -> Make Project
   - Run -> Ejecutar en emulador o dispositivo real

4) APK:
   - Para generar APK: Build -> Build Bundle(s) / APK(s) -> Build APK(s)
   - El APK aparecerá en app/build/outputs/apk/

5) Nota: este proyecto es un esqueleto de ejemplo. Revisa versiones de librerías en caso de errores.

