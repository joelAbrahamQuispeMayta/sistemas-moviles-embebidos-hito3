Sustituir con capturas de pantalla reales una vez ejecutes la app.
