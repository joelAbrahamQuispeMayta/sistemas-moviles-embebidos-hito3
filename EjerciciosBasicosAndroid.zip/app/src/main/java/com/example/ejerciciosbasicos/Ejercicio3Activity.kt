package com.example.ejerciciosbasicos

import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout

class Ejercicio3Activity : AppCompatActivity() {
    private var toggled = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ej3)

        val root = findViewById<ConstraintLayout>(R.id.root_ej3)
        findViewById<Button>(R.id.btn_toggle_color).setOnClickListener {
            toggled = !toggled
            if (toggled) {
                root.setBackgroundColor(Color.parseColor("#BBDEFB")) // light blue
            } else {
                root.setBackgroundColor(Color.WHITE)
            }
        }
    }
}
