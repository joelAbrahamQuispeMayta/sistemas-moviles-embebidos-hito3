package com.example.ejerciciosbasicos

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Ejercicio2Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ej2)

        val tv = findViewById<TextView>(R.id.tv_result)
        findViewById<Button>(R.id.btn_show).setOnClickListener {
            tv.text = "¡Has presionado el botón!"
        }
    }
}
