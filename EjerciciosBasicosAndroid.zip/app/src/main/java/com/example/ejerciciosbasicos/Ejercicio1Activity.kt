package com.example.ejerciciosbasicos

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class Ejercicio1Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ej1)

        findViewById<Button>(R.id.btn_toast).setOnClickListener {
            Toast.makeText(this, "Hola Mundo", Toast.LENGTH_SHORT).show()
        }
    }
}
