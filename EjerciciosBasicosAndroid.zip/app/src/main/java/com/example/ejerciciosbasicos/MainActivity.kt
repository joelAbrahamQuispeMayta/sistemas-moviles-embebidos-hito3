package com.example.ejerciciosbasicos

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btn_ej1).setOnClickListener {
            startActivity(Intent(this, Ejercicio1Activity::class.java))
        }
        findViewById<Button>(R.id.btn_ej2).setOnClickListener {
            startActivity(Intent(this, Ejercicio2Activity::class.java))
        }
        findViewById<Button>(R.id.btn_ej3).setOnClickListener {
            startActivity(Intent(this, Ejercicio3Activity::class.java))
        }
        findViewById<Button>(R.id.btn_ej4).setOnClickListener {
            startActivity(Intent(this, Ejercicio4Activity::class.java))
        }
        findViewById<Button>(R.id.btn_ej5).setOnClickListener {
            startActivity(Intent(this, Ejercicio5Activity::class.java))
        }
    }
}
