package com.example.ejerciciosbasicos

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class Ejercicio5Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ej5)

        val img = findViewById<ImageView>(R.id.iv_hidden)
        img.visibility = View.GONE

        findViewById<Button>(R.id.btn_show_image).setOnClickListener {
            img.visibility = View.VISIBLE
        }
    }
}
