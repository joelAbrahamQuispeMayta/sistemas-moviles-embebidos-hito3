Proyecto: EjerciciosBasicosAndroid (un solo proyecto con 5 actividades)

Actividades:
- MainActivity: menú con botones para abrir cada ejercicio.
- Ejercicio1Activity: Mostrar Toast "Hola Mundo".
- Ejercicio2Activity: Mostrar texto en TextView al presionar botón.
- Ejercicio3Activity: Alternar color fondo entre blanco y azul claro.
- Ejercicio4Activity: Contador que incrementa en 1 al presionar.
- Ejercicio5Activity: Imagen oculta que se muestra al presionar botón.

Cómo usar:
1) Abrir esta carpeta en Android Studio (Open Project).
2) Build -> Make Project.
3) Run en emulador o dispositivo.

Notas:
- Código en Kotlin.
- Si deseas que prepare también el APK, puedo intentar generarlo aquí (puede fallar) o darte instrucciones para generarlo localmente.
