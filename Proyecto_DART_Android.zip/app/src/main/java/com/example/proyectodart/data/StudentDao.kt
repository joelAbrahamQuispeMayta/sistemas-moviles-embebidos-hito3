package com.example.proyectodart.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface StudentDao {
    @Insert
    suspend fun insert(student: Student): Long

    @Query("SELECT * FROM students ORDER BY id DESC")
    suspend fun getAll(): List<Student>

    @Query("SELECT * FROM students WHERE name LIKE :q")
    suspend fun searchByName(q: String): List<Student>
}
