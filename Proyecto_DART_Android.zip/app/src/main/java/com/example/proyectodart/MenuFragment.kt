package com.example.proyectodart

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.commit

class MenuFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val v = inflater.inflate(R.layout.fragment_menu, container, false)
        v.findViewById<View>(R.id.btn_calc).setOnClickListener {
            parentFragmentManager.commit {
                replace(R.id.container, CalculatorFragment())
                addToBackStack(null)
            }
        }
        v.findViewById<View>(R.id.btn_students).setOnClickListener {
            parentFragmentManager.commit {
                replace(R.id.container, StudentsFragment())
                addToBackStack(null)
            }
        }
        return v
    }
}
