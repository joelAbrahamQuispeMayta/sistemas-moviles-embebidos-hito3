package com.example.proyectodart

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.proyectodart.data.AppDatabase
import com.example.proyectodart.data.Student
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class StudentsFragment : Fragment() {
    private lateinit var db: AppDatabase

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val v = inflater.inflate(R.layout.fragment_students, container, false)
        db = AppDatabase.getInstance(requireContext())

        val nameInput = v.findViewById<EditText>(R.id.input_name)
        val gradesInput = v.findViewById<EditText>(R.id.input_grades)
        val btnAdd = v.findViewById<Button>(R.id.btn_add)
        val btnList = v.findViewById<Button>(R.id.btn_list)
        val btnAvg = v.findViewById<Button>(R.id.btn_avg)
        val tvList = v.findViewById<TextView>(R.id.tv_list)
        val tvAvg = v.findViewById<TextView>(R.id.tv_avg)

        btnAdd.setOnClickListener {
            val name = nameInput.text.toString().trim()
            val grades = gradesInput.text.toString().trim()
            if (name.isEmpty() || grades.isEmpty()) {
                tvList.text = "Nombre y notas requeridos"
                return@setOnClickListener
            }
            lifecycleScope.launch {
                db.studentDao().insert(Student(name = name, gradesCsv = grades))
                withContext(Dispatchers.Main) {
                    nameInput.text.clear()
                    gradesInput.text.clear()
                    tvList.text = "Estudiante agregado"
                }
            }
        }

        btnList.setOnClickListener {
            lifecycleScope.launch {
                val all = db.studentDao().getAll()
                val sb = StringBuilder()
                for (s in all) {
                    sb.append(s.name).append(" — Notas: ").append(s.gradesCsv).append("\n")
                }
                withContext(Dispatchers.Main) {
                    tvList.text = sb.toString()
                }
            }
        }

        btnAvg.setOnClickListener {
            lifecycleScope.launch {
                val all = db.studentDao().getAll()
                val grades = all.flatMap { it.gradesCsv.split(',').mapNotNull { it.trim().toDoubleOrNull() } }
                val avg = if (grades.isEmpty()) 0.0 else grades.average()
                withContext(Dispatchers.Main) {
                    tvAvg.text = "Promedio general: %.2f".format(avg)
                }
            }
        }

        return v
    }
}
