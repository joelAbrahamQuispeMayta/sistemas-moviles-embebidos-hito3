package com.example.proyectodart

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.fragment.app.Fragment

class CalculatorFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val v = inflater.inflate(R.layout.fragment_calculator, container, false)
        val aInput = v.findViewById<EditText>(R.id.input_a)
        val bInput = v.findViewById<EditText>(R.id.input_b)
        val opSpinner = v.findViewById<Spinner>(R.id.spinner_op)
        val resultTv = v.findViewById<TextView>(R.id.tv_result)
        v.findViewById<Button>(R.id.btn_calc).setOnClickListener {
            val a = aInput.text.toString().toDoubleOrNull()
            val b = bInput.text.toString().toDoubleOrNull()
            if (a == null || b == null) {
                resultTv.text = "Ingresa números válidos"
                return@setOnClickListener
            }
            val op = opSpinner.selectedItem.toString()
            val res = when(op) {
                "Sumar" -> a + b
                "Restar" -> a - b
                "Multiplicar" -> a * b
                "Dividir" -> if (b == 0.0) { Double.NaN } else a / b
                else -> 0.0
            }
            resultTv.text = "Resultado: $res"
        }
        return v
    }
}
