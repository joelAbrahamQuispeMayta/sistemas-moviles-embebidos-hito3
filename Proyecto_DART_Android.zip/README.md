Proyecto DART - Android (Kotlin)

Estructura:
- app/src/main/java/com/example/proyectodart/  -> código Kotlin (MainActivity, Fragments)
- app/src/main/res/layout/ -> layouts XML
- app/build.gradle -> módulo app Gradle config
- build.gradle, settings.gradle -> proyecto

Funcionalidades:
1) Calculadora: sumar, restar, multiplicar, dividir.
2) Gestión de estudiantes: agregar (nombre + notas CSV), listar y calcular promedio general. Persistencia con Room.

Cómo abrir y ejecutar:
1. Abre Android Studio.
2. Selecciona 'Open' y abre la carpeta `Proyecto_DART_Android`.
3. Deja que Gradle sincronice. Asegúrate de tener el SDK y herramientas compatibles (Compile SDK 34).
4. Ejecuta la app en un emulador o dispositivo físico.

Nota: Este es un esqueleto funcional pensado para fines de estudio. Puedes mejorar validaciones, UI y pruebas.
